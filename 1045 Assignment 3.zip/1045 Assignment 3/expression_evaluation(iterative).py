"""
This program will compute the result of binary arithmetic expressions in a list via iterations
using while loop or for loop and is restricted to use recursion and eval function.
The results will return in float data type.
"""


def evaluate_expression_iter(expr_list: list) -> float:
    """
    This function will evaluate binary arithmetic expression via iteration without using eval function,recursion,
    and assume the format of the list is e = [e1,e2,e3], where e1 is operator,e2 and e3 is numbers or a list

        Parameters:
            expr_list: a list of binary arithmetic expression need to be evaluated

        Returns:
            The result of a binary arithmetic expression in float

    """
    # expr_list_copied is used for 1st and 2nd while loop
    # expr_list act as the original list used in 3rd while loop,to replace inner list with answer from expr_lst_copied
    expr_list_copied = expr_list.copy()
    current_answer = 0
    final_answer = 0

    while len(expr_list_copied) > 1:
        replaced_list = []  # to store the list that replace expr_list_copied everytime it loop through 2nd while loop
        index_replaced_list = []  # to store which index in the list replace expr_list_copied (e2/e3)
        operation_status = False
        # this while loop find the innermost list and calculate the answer of the list
        while True:
            # when e2 is a list
            if isinstance(expr_list_copied[1], list):
                replaced_list.append(expr_list_copied[1])
                index_replaced_list.append("e2")
                expr_list_copied = expr_list_copied[1]  # loop back with e2
                continue
            # when e3 is a list
            elif isinstance(expr_list_copied[2], list):
                replaced_list.append(expr_list_copied[2])
                index_replaced_list.append("e3")
                expr_list_copied = expr_list_copied[2]  # loop back with e3
            # when both e2,e3 is integer/float,indicate it's the innermost list
            elif isinstance(expr_list_copied[1], (int, float)) and isinstance(expr_list_copied[2], (int, float)):
                operation_status = True
            # calculation perform only when it's innermost list
            if operation_status == True:
                if expr_list_copied[0] == '+':
                    current_answer = expr_list_copied[1] + expr_list_copied[2]
                elif expr_list_copied[0] == '-':
                    current_answer = expr_list_copied[1] - expr_list_copied[2]
                elif expr_list_copied[0] == '*':
                    current_answer = expr_list_copied[1] * expr_list_copied[2]
                elif expr_list_copied[0] == '/':
                    current_answer = expr_list_copied[1] / expr_list_copied[2]
                break
        # if replaced_list is empty,indicate there's no more inner expression to be calculated
        # this is the final answer
        if len(replaced_list) == 0:
            final_answer = float(current_answer)
            break
        # otherwise replace the innermost list of expr_list with current_answer
        # loop back the 1st while loop
        else:
            operator = expr_list[0]  # separate original list into [e1,e2,e3]
            e2 = expr_list[1]
            e3 = expr_list[2]
            ori_list_replaced = [operator, e2, e3]
            depth = 0
            incomplete_update = True
            # this while loop will retrieve list in expr_list that need to be replaced from replaced_list
            while True:
                for value in ori_list_replaced:
                    # find value match replaced_list at idx0
                    if value == replaced_list[0]:
                        if len(replaced_list) != 1:  # indicate ori_list_replaced not the innermost list
                            ori_list_replaced = value
                            replaced_list.pop(0)
                            depth += 1
                        elif len(replaced_list) == 1:  # ori_list_replaced is the innermost list
                            idx = ori_list_replaced.index(value)
                            value = current_answer
                            ori_list_replaced[idx] = value  # replace with current_answer
                            # replace expr_list's e2 with new e2
                            if index_replaced_list[0] == "e2":
                                if len(index_replaced_list) == 1:
                                    expr_list = [operator, value, e3]
                                elif len(index_replaced_list) > 1:
                                    if depth == 1:
                                        expr_list = [operator, ori_list_replaced, e3]
                                    elif depth == 2:
                                        expr_list = expr_list
                                expr_list_copied = expr_list
                                incomplete_update = False
                                # replace expr_list's e3 with new e3
                            elif index_replaced_list[0] == "e3":
                                if len(index_replaced_list) == 1:
                                    expr_list = [operator, e2, value]
                                elif len(index_replaced_list) > 1:
                                    if depth == 1:
                                        expr_list = [operator, e2, ori_list_replaced]
                                    elif depth == 2:
                                        expr_list = expr_list
                                expr_list_copied = expr_list
                                incomplete_update = False
                # expr_list updated,back to 1st while loop
                if not incomplete_update:
                    break
    return final_answer


if __name__ == "__main__":
    expr_lists = [['*', ['/', 4, 2], ['+', 8, 7]],
                  ['-', ['+', 3, 4], ['*', ['+', 2, 5], ['*', 3, 3]]],
                  ['-', ['+', ['*', 3, 3], 4], ['*', ['+', ['+', 8, 7], 5], ['*', 3, 3]]],
                  ['+', 12, ['+', ['*', 4, 6], ['/', 12, 2]]]]
    for e in expr_lists:
        print(evaluate_expression_iter(e))

    # The expected printed output:
    # 30.0
    # -56.0
    # -167.0
    # 42.0

