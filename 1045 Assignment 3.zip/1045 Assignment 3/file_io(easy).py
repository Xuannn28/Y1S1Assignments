"""
This program will read strings stored in a text file (parameter as input),store and return(output) binary arithmetic
expression(s) in a list data type by using eval function
"""


def read_expressions_easy(file_name: str) -> list:
    """
    This function will read string from text file and evaluate into binary arithmetic expressions

        Parameters:
            file_name: the text file(.txt) that intend to read

        Returns:
            A list of binary arithmetic expressions

    """
    try:
        with open(file_name,'r') as file_source:
            lines = file_source.readlines()
    except FileNotFoundError:                 # in case incorrect text file's name or giving the wrong file
        raise FileNotFoundError(f"The file does not exist")

    operator = ['+','-','*','/']
    file_content = []   # to store a list of arithmetic expressions evaluated
    for line in lines:
        expression = ""
        for character in line.strip():
            # replace open bracket into close bracket
            if character == '(':
                expression += '['
            elif character == ')':
                expression += ']'
            elif character in operator:  # add single quote to operators
                expression += f"'{character}'"
            elif character == " ":       # add comma within empty spaces
                expression += ', '
            else:
                expression += character
        result = eval(expression)  # evaluate the updated string into binary arithmetic expression
        file_content.append(result)  # append into file_content for final return statement
    return file_content


if __name__ == "__main__":
    expr_lists = read_expressions_easy("./expressions.txt")
    for e in expr_lists:
        print(e)
    #The expected printed output:
    #['*', ['/', 4, 2], ['+', 8, 7]]
    #['-', ['+', 3, 4], ['*', ['+', 2, 5], ['*', 3, 3]]]
    #['-', ['+', ['*', 3, 3], 4], ['*', ['+', ['+', 8, 7], 5], ['*', 3, 3]]]
    #['+', 12, ['+', ['*', 4, 6], ['/', 12, 2]]]
