"""
This program read, store and return binary arithmetic expression(s) from the expressions.txt file by
using recursion
"""

def read_expressions_hard(file_name: str) -> list:
    """
    This function takes the file_name, which consists of strings, as the parameter and return a list of binary
    arithmetic expression
    It reads the string in the text file and call convert_list function to convert it to binary arithmetic expressions
    that stored as list

        Parameters:
            file_name: the text file(.txt) that intend to read

        Returns:
            A list of binary arithmetic expressions

    """
    try:
        with open(file_name, 'r') as file_source:
            lines = file_source.readlines()
    except FileNotFoundError:
        raise FileNotFoundError(f"The file does not exist")

    operator = ['+', '-', '*', '/']
    file_content = []  # store a list of binary arithmetic expressions
    for line in lines:
        expression = ""
        for character in line.strip():
            if character == '(':
                expression += '['
            elif character == ')':
                expression += ']'
            elif character in operator:
                expression += f"{character}"  # add single quote to operators
            elif character == " ":
                expression += ', '  # add comma within empty spaces
            else:
                expression += character
        final_list, _ = convert_list(expression, 0)  # call convert_list function to convert it into list
        file_content.append(final_list[0])
    return file_content


def convert_list(expression: str, index=0) -> tuple:
    """
    This function takes the expression and index as the parameters and return lists of binary arithmetic expressions
    and updated index
    It reads the string expression and convert it to binary arithmetic expressions that stored as list by using
    recursion

        Parameters:
            expression: string of the binary arithmetic expressions
            index: the index of the string expression

        Returns:
            Lists of binary arithmetic expressions and updated index

    """
    result = []  # store a list of binary arithmetic expressions that stored as lists
    while index < len(expression):
        if expression[index] == ']':  # Base case: end of current list
            return result, index + 1

        elif expression[index] == '[':
            inner_list, index = convert_list(expression, index + 1)  # Recursive call to parse the inner list
            result.append(inner_list)

        elif expression[index] in ', ':
            index += 1  # Skip the commas and spaces by adding the index only

        elif expression[index] in '+-*/':
            operator = ''
            while index < len(expression) and expression[index] not in '[], ':
                operator += expression[index]
                index += 1
            result.append(operator)
        else:
            number = ''
            while index < len(expression) and expression[index] not in '[], ':
                number += expression[index]
                index += 1
            result.append(int(number))

    return result, index


if __name__ == "__main__":
    expr_lists = read_expressions_hard("./expressions.txt")
    for e in expr_lists:
        print(e)
    # The expected printed output:
    # ['*', ['/', 4, 2], ['+', 8, 7]]
    # ['-', ['+', 3, 4], ['*', ['+', 2, 5], ['*', 3, 3]]]
    # ['-', ['+', ['*', 3, 3], 4], ['*', ['+', ['+', 8, 7], 5], ['*', 3, 3]]]
    # ['+', 12, ['+', ['*', 4, 6], ['/', 12, 2]]]

