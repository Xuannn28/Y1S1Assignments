"""
This program use unit testing to verify the correctness of the calculator program,which include
1. the format of text file,
2. the equivalency of read_expressions_easy and read_expressions_hard,evaluate_expression_iter and evaluate_expression_rec,
3. the correctness of result from evaluate_expression_iter and evaluate_expression_rec
It helps to ensure that the string format in text file is valid before calculation is performed,
and get the accurate result based on the calculation
"""

import unittest, calculator


class CalculatorTestCase(unittest.TestCase):
    """
    This class defines three functions to verify the correctness and functionality of a calculator program.
    It checks various properties, including the input format of binary arithmetic expressions, the
    equivalence of file I/O functions and expression evaluation functions and the correctness of the output generated
    by the calculator program
    """

    file_path = "test_expressions.txt"

    def test_file(self) -> None:
        """ Requirement 1 - Checking the input format.

        Property 1: check if the number of "(" is the same as ")"
        Property 2: check if there is extra characters after the last closed bracket
        Property 3: check if unsupported exponential operators exist
        Property 4: check if unsupported floor division operators exist
        Property 5: check if unsupported modulus operators exist
        Property 6: check if unsupported factorial operators exist
        Property 7: check if the unwanted characters is in the input
        Property 8: check if negative numbers exist
        Property 9: check if unnecessary positive sign is added to a positive integer
        Property 10: check if the number of operators match the number of expressions created
        Property 11: check if there is zero division error

            Parameters:
                self

        """
        unwanted_characters = '''ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz:'"<>.,\?;[]{}_|@#$^&'''
        operators = '+-*/'

        with open(CalculatorTestCase.file_path, 'r') as file_check:
            lines = file_check.readlines()
            for line in lines:
                content = line.strip()
                count = 0

                # Property 1
                number_of_opened_bracket = content.count('(')
                number_of_closed_bracket = content.count(')')
                assert number_of_opened_bracket == number_of_closed_bracket, "The expression has unbalanced brackets."

                # Property 2
                index_of_last_closed_bracket = content.rfind(')')
                assert len(content) - 1 == index_of_last_closed_bracket, "There are extra characters after closed brackets."

                for i in range(len(content)):
                    if content[i] in operators:  # count the number of operators in the string
                        count += 1

                    # Property 3
                    if content[i] == '*':
                        assert content[i + 1] != '*', "exponentiation cannot be perform in calculator.py"

                    # Property 4
                    if content[i] == '/':
                        assert content[i + 1] != '/', "floor division cannot be perform in calculator.py"

                    # Property 5
                    assert content[i] != '%', "modulus is not supported in calculator.py"

                    # Property 6
                    assert content[i] != '!', "factorial cannot be perform in calculator.py"

                    # Property 7
                    assert content[i] not in unwanted_characters, f"{content[i]} should not contain in this text file"

                    if content[i].isdigit():
                        # Property 8
                        assert content[i - 1] != '-', "Only non-negative integers are allowed"

                        # Property 9
                        assert content[i - 1] != '+', f"Extra '+' sign on {content[i]} is unnecessary"

                    # Property 10
                    if i == len(content) - 1:
                        assert number_of_opened_bracket == count, "The number of operators does not match the number of expressions"

                    # Property 11
                    if content[i] == '/':
                        assert content[i + 4] != '0', "Zero division is not allowed"

    def test_equivalence(self) -> None:
        """ Requirement 2 - Checking the equivalence of the file IO and expression evaluation functions.

        Property 1: Check if the output of the functions read_expressions_easy and read_expressions_hard is the equivalent
        Property 2: Check if the output data type of the functions read_expressions_easy and read_expressions_hard is the equivalent
        Property 3: Check if the output of the functions evaluate_expression_iter and evaluate_expression_rec is the equivalent
        Property 4: Check if the output data type of the functions evaluate_expression_iter and evaluate_expression_rec is the equivalent

                Parameters:
                    self

        """

        # check the equivalency of Task 1 and Task 4
        expressions_easy = calculator.read_expressions_easy(self.file_path)
        expressions_hard = calculator.read_expressions_hard(self.file_path)

        # Property 1
        assert expressions_easy == expressions_hard, "The output of read_expressions_easy and read_expressions_hard is not equivalence"

        # Property 2
        assert type(expressions_easy) == type(expressions_hard), "both data type is different"

        # check the equivalency of Task 2 and Task 3
        for expression in expressions_easy:
            expressions_iter = calculator.evaluate_expression_iter(expression)
            expressions_rec = calculator.evaluate_expression_rec(expression)

            # Property 3
            assert expressions_iter == expressions_rec, "The output of evaluate_expression_iter and evaluate_expression_rec is not equivalence"

            # Property 4
            assert type(expressions_iter) == type(expressions_rec), "both data type is different"

    def test_correctness(self) -> None:
        """ Requirement 3 - Checking the correctness of the output.

        Property 1: check if the answer of evaluate_expression_iter using read_expressions_easy is correct from test_results.txt
        Property 2: check if the answer of evaluate_expression_iter using read_expressions_hard is correct from test_results.txt
        Property 3: check if the answer of evaluate_expression_rec using read_expressions_easy is correct from test_results.txt
        Property 4: check if the answer of evaluate_expression_rec using read_expressions_hard is correct from test_results.txt
        Property 5: check if the data type of evaluate_expression_iter is correct from test_results.txt
        Property 6: check if the data type of evaluate_expression_rec is correct from test_result.txt

            Parameters:
                self

        """

        test_result = "test_results.txt"

        # convert test_expressions.txt into a list via read_expression(easy&hard) function in calculator.py
        convert_list_easy = calculator.read_expressions_easy(self.file_path)
        convert_list_hard = calculator.read_expressions_hard(self.file_path)

        with open(test_result, 'r') as test_result:
            test_lines = test_result.readlines()
            for i in range(len(test_lines)):
                answer = float(test_lines[i].strip())
                answer_iter_easy = calculator.evaluate_expression_iter(convert_list_easy[i])  # answer for iter for easy
                answer_iter_hard = calculator.evaluate_expression_iter(convert_list_hard[i])  # answer for iter for hard
                answer_rec_easy = calculator.evaluate_expression_rec(convert_list_easy[i])  # answer for rec for easy
                answer_rec_hard = calculator.evaluate_expression_rec(convert_list_hard[i])  # answer for rec for hard

                # Property 1
                assert answer == answer_iter_easy, "The answer for read_expression_easy via iteration is incorrect"
                # Property 2
                assert answer == answer_iter_hard, "The answer for read_expression_hard via iteration is incorrect"
                # Property 3
                assert answer == answer_rec_easy, "The answer for read_expression_easy via recursion is incorrect"
                # Property 4
                assert answer == answer_rec_hard, "The answer for read_expression_hard via recursion is incorrect"

                # Property 5
                assert type(answer) == type(answer_iter_easy), "The data type via iteration is not a float"
                # Property 6
                assert type(answer) == type(answer_rec_easy), "The data type via recursion is not a float"


if __name__ == '__main__':
    unittest.main()


