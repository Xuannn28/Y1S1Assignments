"""
This program will compute the result of binary arithmetic expressions in a list via recursion,
without using eval function.
The results will return in float data type.
"""


def evaluate_expression_rec(expr_list: list) -> float:
    """
    This function takes in a list, expr_list as the parameter and return the result of the binary arithmetic expression.
    It evaluates binary arithmetic expression via recursion without using eval function, and assume the format of the
    list is e = [e1,e2,e3], where e1 is operator,e2 and e3 is numbers or a list

        Parameters:
            expr_list: a list of binary arithmetic expression need to be evaluated

        Returns:
            The result of a binary arithmetic expression in float

    """
    # base case: the expr_list with data type integer or float
    if isinstance(expr_list, int) or isinstance(expr_list, float):
        return float(expr_list)
    # if expr_list is a list, it will then perform the calculation
    elif isinstance(expr_list, list):
        operator = expr_list[0]
        operands = expr_list[1:]

        # recursive call to perform addition calculation
        if operator == '+':
            return evaluate_expression_rec(operands[0]) + evaluate_expression_rec(operands[1])
        # recursive call to perform subtraction calculation
        elif operator == '-':
            return evaluate_expression_rec(operands[0]) - evaluate_expression_rec(operands[1])
        # recursive call to perform multiplication calculation
        elif operator == '*':
            return evaluate_expression_rec(operands[0]) * evaluate_expression_rec(operands[1])
        # recursive call to perform division calculation
        elif operator == '/':
            return evaluate_expression_rec(operands[0]) / evaluate_expression_rec(operands[1])


if __name__ == "__main__":
    print(evaluate_expression_rec(['*', ['/', 4, 2], ['+', 8, 7]]))
    print(evaluate_expression_rec(['-', ['+', 3, 4], ['*', ['+', 2, 5], ['*', 3, 3]]]))
    print(evaluate_expression_rec(['-', ['+', ['*', 3, 3], 4], ['*', ['+', ['+', 8, 7], 5], ['*', 3, 3]]]))
    print(evaluate_expression_rec(['+', 12, ['+', ['*', 4, 6], ['/', 12, 2]]]))
    # The expected printed output:
    # 30.0
    # -56.0
    # -167.0
    # 42.0
