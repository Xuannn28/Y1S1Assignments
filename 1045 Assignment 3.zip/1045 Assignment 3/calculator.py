"""
This program contain 4 main functions and other helper function to run a simple calculator.
Simple calculator would read input text file and evaluate into arithmetic expressions,
then compute the result of the expressions.
Main function:
1.read_expression_easy
2.evaluate_expression_iter
3.evaluate_expression_rec
4.read_expressions_hard
Helper function: convert_list
"""

def read_expressions_easy(file_name):
    """
        This function will read string from text file and evaluate into binary arithmetic expressions

            Parameters:
                file_name: the text file(.txt) that intend to read

            Returns:
                A list of binary arithmetic expressions

        """
    try:
        with open(file_name, 'r') as file_source:
            lines = file_source.readlines()
    except FileNotFoundError:  # in case incorrect text file's name or giving the wrong file
        raise FileNotFoundError(f"The file does not exist")

    operator = ['+', '-', '*', '/']
    file_content = []  # to store a list of arithmetic expressions evaluated
    for line in lines:
        expression = ""
        for character in line.strip():
            # replace open bracket into close bracket
            if character == '(':
                expression += '['
            elif character == ')':
                expression += ']'
            elif character in operator:  # add single quote to operators
                expression += f"'{character}'"
            elif character == " ":  # add comma within empty spaces
                expression += ', '
            else:
                expression += character
        result = eval(expression)  # evaluate the updated string into binary arithmetic expression
        file_content.append(result)  # append into file_content for final return statement
    return file_content

def evaluate_expression_iter(expr_list):
    """
       This function will evaluate binary arithmetic expression via iteration without using eval function,recursion,
       and assume the format of the list is e = [e1,e2,e3], where e1 is operator,e2 and e3 is numbers or a list

           Parameters:
               expr_list: a list of binary arithmetic expression need to be evaluated

           Returns:
               The result of a binary arithmetic expression in float

       """
    # expr_list_copied is used for 1st and 2nd while loop
    # expr_list act as the original list used in 3rd while loop,to replace inner list with answer from expr_lst_copied
    expr_list_copied = expr_list.copy()
    current_answer = 0
    final_answer = 0

    while len(expr_list_copied) > 1:
        replaced_list = []  # to store the list that replace expr_list_copied everytime it loop through 2nd while loop
        index_replaced_list = []  # to store which index in the list replace expr_list_copied (e2/e3)
        operation_status = False
        # this while loop find the innermost list and calculate the answer of the list
        while True:
            # when e2 is a list
            if isinstance(expr_list_copied[1], list):
                replaced_list.append(expr_list_copied[1])
                index_replaced_list.append("e2")
                expr_list_copied = expr_list_copied[1]  # loop back with e2
                continue
            # when e3 is a list
            elif isinstance(expr_list_copied[2], list):
                replaced_list.append(expr_list_copied[2])
                index_replaced_list.append("e3")
                expr_list_copied = expr_list_copied[2]  # loop back with e3
            # when both e2,e3 is integer/float,indicate it's the innermost list
            elif isinstance(expr_list_copied[1], (int, float)) and isinstance(expr_list_copied[2], (int, float)):
                operation_status = True
            # calculation perform only when it's innermost list
            if operation_status == True:
                if expr_list_copied[0] == '+':
                    current_answer = expr_list_copied[1] + expr_list_copied[2]
                elif expr_list_copied[0] == '-':
                    current_answer = expr_list_copied[1] - expr_list_copied[2]
                elif expr_list_copied[0] == '*':
                    current_answer = expr_list_copied[1] * expr_list_copied[2]
                elif expr_list_copied[0] == '/':
                    current_answer = expr_list_copied[1] / expr_list_copied[2]
                break
        # if replaced_list is empty,indicate there's no more inner expression to be calculated
        # this is the final answer
        if len(replaced_list) == 0:
            final_answer = float(current_answer)
            break
        # otherwise replace the innermost list of expr_list with current_answer
        # loop back the 1st while loop
        else:
            operator = expr_list[0]  # separate original list into [e1,e2,e3]
            e2 = expr_list[1]
            e3 = expr_list[2]
            ori_list_replaced = [operator, e2, e3]
            depth = 0
            incomplete_update = True
            # this while loop will retrieve list in expr_list that need to be replaced from replaced_list
            while True:
                for value in ori_list_replaced:
                    # find value match replaced_list at idx0
                    if value == replaced_list[0]:
                        if len(replaced_list) != 1:  # indicate ori_list_replaced not the innermost list
                            ori_list_replaced = value
                            replaced_list.pop(0)
                            depth += 1
                        elif len(replaced_list) == 1:  # ori_list_replaced is the innermost list
                            idx = ori_list_replaced.index(value)
                            value = current_answer
                            ori_list_replaced[idx] = value  # replace with current_answer
                            # replace expr_list's e2 with new e2
                            if index_replaced_list[0] == "e2":
                                if len(index_replaced_list) == 1:
                                    expr_list = [operator, value, e3]
                                elif len(index_replaced_list) > 1:
                                    if depth == 1:
                                        expr_list = [operator, ori_list_replaced, e3]
                                    elif depth == 2:
                                        expr_list = expr_list
                                expr_list_copied = expr_list
                                incomplete_update = False
                                # replace expr_list's e3 with new e3
                            elif index_replaced_list[0] == "e3":
                                if len(index_replaced_list) == 1:
                                    expr_list = [operator, e2, value]
                                elif len(index_replaced_list) > 1:
                                    if depth == 1:
                                        expr_list = [operator, e2, ori_list_replaced]
                                    elif depth == 2:
                                        expr_list = expr_list
                                expr_list_copied = expr_list
                                incomplete_update = False
                # expr_list updated,back to 1st while loop
                if not incomplete_update:
                    break
    return final_answer


def evaluate_expression_rec(expr_list):
    """
        This function takes in a list, expr_list as the parameter and return the result of the binary arithmetic expression.
        It evaluates binary arithmetic expression via recursion without using eval function, and assume the format of the
        list is e = [e1,e2,e3], where e1 is operator,e2 and e3 is numbers or a list

            Parameters:
                expr_list: a list of binary arithmetic expression need to be evaluated

            Returns:
                The result of a binary arithmetic expression in float

        """
    # base case: the expr_list with data type integer or float
    if isinstance(expr_list, int) or isinstance(expr_list, float):
        return float(expr_list)
    # if expr_list is a list, it will then perform the calculation
    elif isinstance(expr_list, list):
        operator = expr_list[0]
        operands = expr_list[1:]

        # recursive call to perform addition calculation
        if operator == '+':
            return evaluate_expression_rec(operands[0]) + evaluate_expression_rec(operands[1])
        # recursive call to perform subtraction calculation
        elif operator == '-':
            return evaluate_expression_rec(operands[0]) - evaluate_expression_rec(operands[1])
        # recursive call to perform multiplication calculation
        elif operator == '*':
            return evaluate_expression_rec(operands[0]) * evaluate_expression_rec(operands[1])
        # recursive call to perform division calculation
        elif operator == '/':
            return evaluate_expression_rec(operands[0]) / evaluate_expression_rec(operands[1])


def read_expressions_hard(file_name):
    """
        This function takes the file_name, which consists of strings, as the parameter and return a list of binary
        arithmetic expression
        It reads the string in the text file and call convert_list function to convert it to binary arithmetic expressions
        that stored as list

            Parameters:
                file_name: the text file(.txt) that intend to read

            Returns:
                A list of binary arithmetic expressions

        """
    try:
        with open(file_name, 'r') as file_source:
            lines = file_source.readlines()
    except FileNotFoundError:
        raise FileNotFoundError(f"The file does not exist")

    operator = ['+', '-', '*', '/']
    file_content = []  # store a list of binary arithmetic expressions
    for line in lines:
        expression = ""
        for character in line.strip():
            if character == '(':
                expression += '['
            elif character == ')':
                expression += ']'
            elif character in operator:
                expression += f"{character}"  # add single quote to operators
            elif character == " ":
                expression += ', '  # add comma within empty spaces
            else:
                expression += character
        # call convert_list function to convert expressions in string into list
        final_list, _ = convert_list(expression, 0)
        file_content.append(final_list[0])
    return file_content


def convert_list(expression: str, index=0) -> tuple:
    """
    This function act as a helper functions for read_expressions_hard that takes the expression and index as
    the parameters,return lists of binary arithmetic expressions and updated index
    It reads the string expression and convert it to binary arithmetic expressions that stored as list by using
    recursion

        Parameters:
            expression: string of the binary arithmetic expressions
            index: the index of the string expression

        Returns:
            Lists of binary arithmetic expressions and updated index

    """
    result = []  # store a list of binary arithmetic expressions that stored as lists
    while index < len(expression):

        # Base case: when reaches end of current list,return the result list then continue to the next index
        if expression[index] == ']':
            return result, index + 1

        # The recursive relations: it handles nested expressions by creating sublists within the main list
        # when the character in expression is [ , recursive call to parse the inner list
        elif expression[index] == '[':
            inner_list, index = convert_list(expression, index + 1)
            result.append(inner_list)

        # when the character in expression is a comma or spaces,skip and go to next index
        elif expression[index] in ', ':
            index += 1

        # when the character in expression is an operator, it will enter the while loop,
        # append the characters into the string called operator until it encounters the separators ([],)
        elif expression[index] in '+-*/':
            operator = ''
            while index < len(expression) and expression[index] not in '[], ':
                operator += expression[index]
                index += 1
            result.append(operator)

        # when the character in expression is a digit, it will enter the while loop, 
        # appending the digit into the string called number until it encounters the separators ([],)
        else:
            number = ''
            while index < len(expression) and expression[index] not in '[], ':
                number += expression[index]
                index += 1
            result.append(int(number))

    return result, index

