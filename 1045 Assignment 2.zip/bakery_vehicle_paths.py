import city_data as cd
import math
from geopy.distance import geodesic
from abc import ABC, abstractmethod
import networkx as nx

"""
This program allows user input two cities ID,then output the geodesic distance between them in kilometre
It also output the time travel between two cities that inputted by the user
"""

class City():
    """
    This is a class for creating a new City instance inside BakeryCity class.

    Attributes:
        city_ascii (str): The city name
        lat        (str): latitude of the city
        lng        (str): longitude of the city
        country    (str): country of the city belongs to
        capital    (str): capital of the city
        population (str): population of the city
        id         (str): id of the city
    """

    def __init__(self, city_ascii, lat, lng, country, capital, population, id):
        self.city_ascii = city_ascii
        self.lat = lat
        self.lng = lng
        self.country = country
        self.capital = capital
        self.population = population
        self.id = id

class BakeryCity(ABC):
    """
    This is a class representing available cities in a bakery delivery system.
    All city's data is obtained from city_data.py
    """

    def __init__(self, city_ascii, lat, lng, country, capital, population, id):
        self.city_ascii = city_ascii
        self.lat = lat
        self.lng = lng
        self.country = country
        self.capital = capital
        self.population = population
        self.id = id

    def newCity(self):
        """
        Create new object representing a city and append to cityList
        Filter out the unavailable city then append the existing one to filteredCity
        """
        data = cd.city_data
        for i in range(1, len(data)):
            # if not empty string for city population,create an object converting population into integer
            if len(data[i][7]) > 0:
                populationInt = int(data[i][7])
                newCity = City(data[i][0], data[i][1], data[i][2], data[i][3], data[i][6], populationInt, data[i][8])
                cityList.append(newCity)
            else:  # otherwise city population remain empty string
                newCity = City(data[i][0], data[i][1], data[i][2], data[i][3], data[i][6], data[i][7], data[i][8])
                cityList.append(newCity)

        # for cities that are primary capital or population at least 5 millions,append to filteredCity
        for city in cityList:
            if city.capital == "primary" or city.population >= 5000000:
                filteredCity.append(city)

    def distance(self):
        """
        Calculate the distance between 2 cities ID inputted by users
        @return the distance between departure and destination cities
        """
        global departCity, destCity
        departPosition = []  # lat,lng of depart city
        destPosition = []  # lat,lng of destination city
        departCity = ""  # city_ascii of depart city
        destCity = ""  # city_ascii of destination city
        getDeparture = input("Enter the ID of the departure city:\n")
        getDestination = input("Enter the ID of the destination city:\n")
        for city in filteredCity:
            if city.id == getDeparture:  # get the position of depart city
                departPosition.append(float(city.lat))
                departPosition.append(float(city.lng))
                departCity = city.city_ascii
            if city.id == getDestination:  # get the position of destination city
                destPosition.append(float(city.lat))
                destPosition.append(float(city.lng))
                destCity = city.city_ascii
        print(f"Travel times from {departCity} to {destCity}:")
        distance = math.ceil(geodesic(destPosition, departPosition).kilometers)  # calculate distance between 2 cities
        return distance

    @abstractmethod
    def travelTime(self, initDistance):
        """
        Abstract method to calculate the travel time of each vehicle
        @param initDistance: the distance between depart and destination
        """
        pass

    @abstractmethod
    def infShortestTime(self, initDepartCountry, initDestCountry, initDepartCapital, initDestCapital):
        """
        Abstract method to get the shortest travel time of each vehicle
        when it returns "Infinity" in travelTime
        @param initDepartCountry: the country of depart city
        @param initDestCountry: the country of destination city
        @param initDepartCapital: the capital of depart city
        @param initDestCapital: the capital of destination city
        """
        pass

class CrappyCrepeCar(BakeryCity):
    """
    This class representing CrappyCrepeCar as a vehicle for bakery delivery from depart to destination city,
    returning the duration for delivery in hours
    """

    def travelTime(self, distance1):
        """
        Abstract method to calculate the travel time of each vehicle
        @param distance1: the distance between depart and destination
        @return travel duration between departure to destination
        """
        time = ""
        speed = 250
        time1 = math.ceil(distance1 / speed)  # the time calculated round up to the nearest integer
        time += str(time1)  # concatenate time to string for display purpose
        return time

    # since this vehicle do not have "Infinity" hours,pass this function
    def infShortestTime(self, departCountry1, destCountry1, departCapital1, destCapital1):
        """
        Abstract method to get the shortest travel time of each vehicle
        when it returns "Infinity" in travelTime
        @param departCountry1: the country of depart city
        @param destCountry1: the country of destination city
        @param departCapital1: the capital of depart city
        @param destCapital1: the capital of destination city
        """
        pass

class DiplomacyDonutDinghy(BakeryCity):
    """
    This class representing DiplomacyDonutDinghy as a vehicle for bakery delivery from depart to destination city,
    returning the duration for delivery in hours

    Attributes:
        attributes are inherited from BakeryCity class
        domSpeed  (int): domestic speed of dinghy
        intSpeed  (int): international speed of dinghy
    """

    def __init__(self, city_ascii, lat, lng, country, capital, population, id, domSpeed, intSpeed):
        super().__init__(city_ascii, lat, lng, country, capital, population, id)
        self.domSpeed = domSpeed
        self.intSpeed = intSpeed

    def travelTime(self, distance2):
        """
        Abstract method to calculate the travel time of each vehicle
        @param distance2: the distance between depart and destination
        @return travel duration,country,capital of departure and destination
        """
        departCountry = ""  # country of depart city
        destCountry = ""  # country of destination city
        departCapital = ""  # capital of depart city
        destCapital = ""  # capital of destination city
        time = ""  # concatenate duration to string for display purpose

        # get country,capital of depart and destination city
        for city in filteredCity:
            if city.city_ascii == departCity:
                departCountry = city.country
                departCapital = city.capital
            elif city.city_ascii == destCity:
                destCountry = city.country
                destCapital = city.capital
        # if both in same country/primary capital,calculate the duration
        if departCountry == destCountry:
            time1 = math.ceil(distance2 / self.domSpeed)
            time += str(time1)
        elif departCapital == "primary" and destCapital == "primary":
            time1 = math.ceil(distance2 / self.intSpeed)
            time += str(time1)
        else:
            time += "Infinity"
        return time, departCountry, destCountry, departCapital, destCapital

    # when time is infinity,invoke this function
    def infShortestTime(self, departCountry2, destCountry2, departCapital2, destCapital2):
        """
        Abstract method to get the shortest travel time of each vehicle
        when it returns "Infinity" in travelTime
        @param departCountry2: the country of depart city
        @param destCountry2: the country of destination city
        @param departCapital2: the capital of depart city
        @param destCapital2: the capital of destination city
        @return shortest duration to travel from departure to destination
        """
        departList = []  # store all city same country with departure
        destList = []  # store all city same country with destination
        totalTime = 0  # sum up total duration take to reach destination

        # get the cities same country with depart and destination
        for city1 in filteredCity:
            if city1.country == departCountry2:
                departList.append(city1)
            elif city1.country == destCountry2:
                destList.append(city1)

        # get the primary capital city of depart and destination city
        primaryDepart = [city2 for city2 in departList if city2.capital == "primary"]
        position1 = (float(primaryDepart[0].lat),float(primaryDepart[0].lng))   # position of primary city of departure
        primaryDest = [city2 for city2 in destList if city2.capital == "primary"]
        position2 = (float(primaryDest[0].lat),float(primaryDest[0].lng))  # position of primary city of departure

        #if departcity not primary,go to primary first
        if departCapital2 != "primary":
            for city3 in departList:
                if city3.city_ascii == departCity:
                    curCityPos = (float(city3.lat),float(city3.lng))
                    distance1 = math.ceil(geodesic(curCityPos,position1).kilometers)
                    time1 = math.ceil(distance1/self.domSpeed)
                    totalTime += time1

        # from primary city of departure to primary city of destination
        distance = math.ceil(geodesic(position1, position2).kilometers)
        time2 = math.ceil(distance / self.intSpeed)
        totalTime += time2

        # if dest not primary,go to dest
        if destCapital != "primary":
            for city4 in destList:
                if city4.city_ascii == destCity:
                    curCityPos = (float(city4.lat), float(city4.lng))
                    distance1 = math.ceil(geodesic(curCityPos, position2).kilometers)
                    time3 = math.ceil(distance1 / self.domSpeed)
                    totalTime += time3

        return totalTime

class TeleportingTarteTrolley(BakeryCity):
    """
    This class representing TeleportingTarteTrolley as a vehicle for bakery delivery from depart to destination city,
    returning the duration for delivery in hours

    Attributes:
        attributes are inherited from BakeryCity class
        blinkTime  (int): travel duration of trolley
        blinkRange  (int): max distance trolley can teleport
    """

    def __init__(self, city_ascii, lat, lng, country, capital, population, id, blinkTime, blinkRange):
        super().__init__(city_ascii, lat, lng, country, capital, population, id)
        self.blinkTime = blinkTime
        self.blinkRange = blinkRange

    def travelTime(self, distance3):
        """
        Abstract method to calculate the travel time of each vehicle
        @param distance3: the distance between depart and destination
        @return travel duration between departure to destination
        """
        time = ""
        if distance3 <= self.blinkRange:   #if distance less than blinkRange,can teleport
            time += str(self.blinkTime)
        else:
            time += "Infinity"
        return time

    # when time is infinity,invoke this function
    def infShortestTime(self, departCountry3, destCountry3, departCapital3, destCapital3):
        """
        Abstract method to get the shortest travel time of each vehicle
        when it returns "Infinity" in travelTime
        @param departCountry3: the country of depart city
        @param destCountry3: the country of destination city
        @param departCapital3: the capital of depart city
        @param destCapital3: the capital of destination city
        @return shortest duration to travel from departure to destination
        """
        # if distance between 2 cities <= blinkRange,add edge with weight=blinkTime
        for i in range(len(filteredCity)):
            source = filteredCity[i].city_ascii
            data1 = newGraph1.nodes[source]
            for j in range(i+1, len(filteredCity)):
                target = filteredCity[j].city_ascii
                data2 = newGraph1.nodes[target]
                distance = geodesic((data1["lat1"], data1["lng1"]), (data2["lat1"], data2["lng1"])).kilometers
                if distance <= self.blinkRange:
                    newGraph1.add_edge(source, target, weight=self.blinkTime)

        # find the shortest duration from depart to destination
        shortestDuration = nx.shortest_path_length(newGraph1, source=departCity, target=destCity,weight='weight')
        return shortestDuration

if __name__ == "__main__":
    cityList = []  # to store all cities created as an object in BakeryCity
    filteredCity = []  # cities that is filtered out via specific condition from cityList
    car = CrappyCrepeCar("", "", "", "", "", "", "")
    car.newCity()
    C = nx.Graph()
    # from filtered list, city_ascii as node,with attribute country,capital,lat,lng
    for city in filteredCity:
        C.add_node(city.city_ascii,lat1=float(city.lat),lng1=float(city.lng),country1=city.country,capital1=city.capital)
    print(f"Delivering baked goods to 363 cities.")
    print("Bakery vehicles:")
    print(" 0. Crappy Crepe Car (crappy speed: 250 km/h)")
    print(" 1. Diplomacy Donut Dinghy (domestic speed: 100 km/h | international speed: 500 km/h)")
    print(" 2. Diplomacy Donut Dinghy (domestic speed: 50 km/h | international speed: 800 km/h)")
    print(" 3. Teleporting Tarte Trolley (blink time: 6 h | blink range: 2000 km)")
    print(" 4. Teleporting Tarte Trolley (blink time: 8 h | blink range: 3000 km)")
    cityDistance = car.distance()
    carTime = car.travelTime(cityDistance)
    dinghy1 = DiplomacyDonutDinghy("", "", "", "", "", "", "", 100, 500)
    dinghyTime1, departCountry, destCountry, departCapital, destCapital = dinghy1.travelTime(cityDistance)
    if dinghyTime1 == "Infinity":
         finalTime1 = dinghy1.infShortestTime(departCountry, destCountry, departCapital, destCapital)
    else:
         finalTime1 = dinghyTime1
    dinghy2 = DiplomacyDonutDinghy("", "", "", "", "", "", "", 50, 800)
    dinghyTime2, departCountry, destCountry, departCapital, destCapital = dinghy2.travelTime(cityDistance)
    if dinghyTime2 == "Infinity":
        finalTime2 = dinghy2.infShortestTime(departCountry, destCountry, departCapital, destCapital)
    else:
        finalTime2 = dinghyTime2
    trolley1 = TeleportingTarteTrolley("", "", "", "", "", "", "", 6, 2000)
    trolleyTime1 = trolley1.travelTime(cityDistance)
    if trolleyTime1 == "Infinity":
        newGraph1 = C.copy()   # made a copy of graph C to add edge on it 
        finalTime3 = trolley1.infShortestTime(departCountry, destCountry, departCapital, destCapital)
    else:
        finalTime3 = trolleyTime1
    trolley2 = TeleportingTarteTrolley("", "", "", "", "", "", "", 8, 3000)
    trolleyTime2 = trolley2.travelTime(cityDistance)
    if trolleyTime2 == "Infinity":
        newGraph1 = C.copy()
        finalTime4 = trolley2.infShortestTime(departCountry, destCountry, departCapital, destCapital)
    else:
        finalTime4 = trolleyTime2
    timeList = [carTime, finalTime1, finalTime2, finalTime3, finalTime4]
    for i in range(len(timeList)):        # display final output
        print(f" {i}. {timeList[i]} hours")

