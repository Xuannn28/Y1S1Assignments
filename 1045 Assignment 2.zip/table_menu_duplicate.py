import table_data as td        # import the data from table_data.py
from tabulate import tabulate      # import from tabulate library 

"""
This program allow users to choose several options,eg.show a table list,
display table or duplicate table.
The tables is created from data provided in table_data.py
"""

def main():
    """
    Main function to show the main menu and allow user 
    to input an integer to run the corresponding options
    """
    table = createTable()   # tabulate the tables from table_data.py
    while True:
        print("==================================")
        print("Enter your choice:")
        print("1. List tables.")
        print("2. Display table.")
        print("3. Duplicate table.")
        print("0. Quit.")
        print("==================================")
        option = input()    # allow user to choose options
        if option == '1':
            print(listTable())
        elif option == '2':
            displayTable(table)
        elif option == '3':
            duplicateTable(table)
        elif option == '0':
            quit()
        else:
            print("Incorrect table index. Try again.") # display this when the input is not in the options
            continue  # ask for input again

def listTable():
    """
    List out all existing tables ,by showing the index and
    number of columns and rows
    @return the existing list of tables 
    """
    listTableData = []
    header = ["Index","Columns","Rows"]
    for i in range(len(td.tables)):
        for rows in td.tables[i]:
            numofRows = len(td.tables[i])
            numOfColumns = len(rows)
        myList=[i,numOfColumns,numofRows]
        newTuple = tuple(myList)
        listTableData.append(newTuple)  #listTableData=[(0,5,6),....]

    tableList = tabulate(listTableData,headers = header)
    return tableList

def createTable():
    """
    tabulate data in table_data.py
    @return the tabulated tables
    """
    #tabulate each table here
    #grades
    gradeHeader = td.grades[0]
    gradeData = td.grades[1:]
    gradeTable = tabulate(gradeData,headers=gradeHeader)

    #class_students
    classHeader = td.class_students[0]
    classData = td.class_students[1:]
    classTable = tabulate(classData,headers=classHeader)

    #club
    clubHeader = td.rabbytes_club_students[0]
    clubData = td.rabbytes_club_students[1:]
    clubTable = tabulate(clubData,headers=clubHeader)

    #rabbyte
    rabbyteHeader = td.rabbytes_data[0]
    rabbyteData = td.rabbytes_data[1:]
    rabbyteTable = tabulate(rabbyteData,headers=rabbyteHeader)

    displayOption = [gradeTable,classTable,clubTable,rabbyteTable]
    return displayOption

def displayTable(newTable):
    """
    Display the table based on the index inputted by the user
    @param newTable: tables created from createTable() 
    """
    while True:
        getTable = int(input("Choose a table index (to display):\n")) # allow user to input the index of the table
        # ensure getTable within valid range
        if getTable>=0 and getTable<len(td.tables):
            print(newTable[getTable]) # display the table chosen
            break
        else:
            print("Incorrect table index. Try again.")
            continue

def duplicateTable(newTable):
    """
    Duplicate the table based on the index inputted by the user
    @param newTable: tables created from createTable()
    @return updated data and updated table
    """
    while True:
        getTable = int(input("Choose a table index (to duplicate):\n")) # allow user to input the index of the table

        if getTable >= 0 and getTable < len(td.tables):
            td.tables.append(td.tables[getTable]) # append the duplicate table
            newTable.append(newTable[getTable])
            break
        else:
            print("Incorrect table index. Try again.")
            continue
    return td.tables, newTable

main()



