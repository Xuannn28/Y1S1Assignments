import copy                      #import from copy library
import table_data as td          #import the data from table_data.py
from tabulate import tabulate    #import from tabulate library

"""
This program allows users to choose several options,eg.show a table list,
display table,duplicate table,create new tables,delete tables,delete table's column and restore deleted tables
The tables is created from data provided in table_data.py
"""

def main():
    """
    Main function to show the main menu and allow user 
    to input an integer to run the corresponding options
    """
    table = createTable()    # tabulate the tables from table_data.py
    while True:
        print("==================================")
        print("Enter your choice:")
        print("1. List tables.")
        print("2. Display table.")
        print("3. Duplicate table.")
        print("4. Create table.")
        print("5. Delete table.")
        print("6. Delete column.")
        print("7. Restore table.")
        print("0. Quit.")
        print("==================================")
        option = input()    # allow user choose options
        if option == '1':
            print(listTable())
        elif option == '2':
            displayTable(table)
        elif option == '3':
            duplicateTable(table)
        elif option == '4':
            createNewTable(table)
        elif option == '5':
            data1,tables,initData,initTable = deleteTable(table)
        elif option == '6':
            deleteColumn(table)
        elif option == '7':
            restoreTable(initData,initTable,table)
        elif option == '0':
            quit()
        else:
            print("Incorrect table index. Try again.")   # display this when the input is not in the options
            continue

def listTable():
    """
    List out all existing tables,by showing the index and
    number of columns and rows
    @return the existing list of tables 
    """
    listTableData = []
    header = ["Index","Columns","Rows"]
    for i in range(len(td.tables)):
        for rows in td.tables[i]:
            numofRows = len(td.tables[i])
            numOfColumns = len(rows)
        myList=[i,numOfColumns,numofRows]
        newTuple=tuple(myList)
        if (newTuple[2]!=1):     # check if number of rows !=1,to exclude deleted table('x') without changing index of other tables
            listTableData.append(newTuple)

    tableList = tabulate(listTableData,headers=header)
    return tableList


def createTable():
    """
    tabulate every tables in table_data.py
    @return the tabulated tables
    """
    #tabulate each table here
    #grades
    gradeHeader = td.grades[0]
    gradeData = td.grades[1:]
    gradeTable = tabulate(gradeData,headers=gradeHeader)

    #class_students
    classHeader = td.class_students[0]
    classData = td.class_students[1:]
    classTable = tabulate(classData,headers=classHeader)

    #club
    clubHeader = td.rabbytes_club_students[0]
    clubData = td.rabbytes_club_students[1:]
    clubTable = tabulate(clubData,headers=clubHeader)

    #rabbyte
    rabbyteHeader = td.rabbytes_data[0]
    rabbyteData = td.rabbytes_data[1:]
    rabbyteTable = tabulate(rabbyteData,headers=rabbyteHeader)

    displayOption = [gradeTable,classTable,clubTable,rabbyteTable]
    return displayOption

def displayTable(table1):
    """
    Display the table based on the index of table inputted by the user
    @param table1: tables created from createTable()
    """
    while True:
        getTable = int(input("Choose a table index (to display):\n"))    
         # ensure getTable within valid range and not a deleted table
        if getTable>=0 and getTable<len(td.tables) and td.tables[getTable] !="x":
            print(table1[getTable])   #display the table
            break
        else:
            print("Incorrect table index. Try again.")
            continue

def duplicateTable(table2):
    """
    Duplicate the table based on the index of table input by the user
    @param table2: tables created from createTable()
    @return updated data and updated tables
    """
    while True:
        getTable = int(input("Choose a table index (to duplicate):\n"))     

        if getTable >= 0 and getTable < len(td.tables) and td.tables[getTable] != "x":
            td.tables.append(td.tables[getTable])  #duplicated data append to td.tables
            table2.append(table2[getTable])        #duplicated table append to table2
            break
        else:
            print("Incorrect table index. Try again.")
            continue
    return td.tables,table2

def createNewTable(table3):
    """
    Create new table based on the index and columns to keep inputted by the user
    @param table3: tables created from createTable()
    @return the new tabulated table
    """
    while True:
        getTable = int(input("Choose a table index (to create from):\n"))    

        if getTable >= 0 and getTable < len(td.tables) and td.tables[getTable] != "x":
            tableCreateFrom = td.tables[getTable]
            getColumns = input("Enter the comma-separated indices of the columns to keep:\n")
            indices = getColumns.split(',')
            int_indices = [int(x) for x in indices]     # change to list of integer
            headerList = []     #empty list to store the header
            dataList = []       #empty list to store the table data
            for index in int_indices:
                header = tableCreateFrom[0][index]      
                headerList.append(header)
            for rows in tableCreateFrom[1:]:
                rowData = []
                for index in int_indices:
                    data = rows[index]
                    rowData.append(data)
                dataList.append(rowData)

            #create new table
            newTable = tabulate(dataList,headers=headerList)
            table3.append(newTable)       #update tables(table3) and data(td.tables)
            dataList.insert(0,headerList)
            td.tables.append(dataList)
            break
        else:
            print("Incorrect table index. Try again.")
            continue

    return newTable


def deleteTable(table4):
    """
    Delete table based on the index inputted by the user
    @param table4: tables created from createTable()
    @return updated data and updated table
    """
    while True:
        getTable = int(input("Choose a table index (for table deletion):\n"))    
        if getTable >= 0 and getTable < len(td.tables) and td.tables[getTable] != "x":
            initData = copy.deepcopy(td.tables)     # copy the undeleted data and tables using deepcopy
            initTable = copy.deepcopy(table4)       
            td.tables[getTable] = "x"       #replace chosen deleted data as 'x'
            table4[getTable] = "x"          #replace chosen deleted table as 'x'
            break
        else:
            print("Incorrect table index. Try again.")
            continue

    return td.tables,table4,initData,initTable

def deleteColumn(table5):
    """
    Delete the column of table based on the index of table and column to delete inputted by the user
    @param table5: tables created from createTable()
    @return updated data and updated table
    """
    while True:
        getTable = int(input("Choose a table index (for column deletion):\n"))      
        if getTable >= 0 and getTable < len(td.tables) and td.tables[getTable] != "x":
            deleteColumnFrom = copy.deepcopy(td.tables[getTable]) # deepcopy the table so that did not affect duplicated table/original table
            getIndex = int(input("Enter the index of the column to delete:\n"))
            headerList = deleteColumnFrom[0]
            headerList.remove(headerList[getIndex])    # remove the headers of the column to delete

            dataList=[]
            for rows in deleteColumnFrom[1:]:
                data = rows
                data.remove(data[getIndex])
                dataList.append(data)
            # create new table
            newTable = tabulate(dataList,headers=headerList)
            # replace old table with new table
            table5[getTable] = newTable
            dataList.insert(0,headerList)
            td.tables[getTable]=dataList   # replace old data with new data
            break
        else:
            print("Incorrect table index. Try again.")
            continue

    return table5,td.tables

def restoreTable(oriData,oriTable,table6):
    """
    Restore the table that is deleted based on the table index inputte by the user 
    @param oriData: initData from deleteTable()
    @param oriTable: initTable from deleteTable()
    @param table6: tables created from createTable()
    @return updated data and updated table
    """
    while True:
        getTable = int(input("Choose a table index (for restoration):\n"))  
        if getTable >= 0 and getTable < len(td.tables):
            if td.tables[getTable] == "x":
                td.tables[getTable] = oriData[getTable]     #restore deleted data('x') back
                table6[getTable] = oriTable[getTable]       #restore deleted table('x') back
                break
            else:
                print("Incorrect table index. Try again.")  # when td.tables[getTable] !='x'
                continue
        else:
            print("Incorrect table index. Try again.")
            continue

    return td.tables,table6
main()



