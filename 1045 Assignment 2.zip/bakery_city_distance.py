import city_data as cd
import math
from geopy.distance import geodesic

"""
This program allows user input two cities ID,then output the geodesic distance
between them in kilometre
"""

class BakeryCity():
    """
    This is a class representing available cities in a bakery delivery system.
    All city's data is obtained from city_data.py

    Attributes:
        city_ascii (str): The city name
        lat        (str): latitude of the city
        lng        (str): longitude of the city
        country    (str): country of the city belongs to
        capital    (str): capital of the city
        population (str): population of the city
        id         (str): id of the city
    """
    def __init__(self,city_ascii,lat,lng,country,capital,population,id):
        self.city_ascii = city_ascii
        self.lat = lat
        self.lng = lng
        self.country = country
        self.capital = capital
        self.population = population
        self.id = id

    def newCity(self):
        """
        Create new object representing a city and append to cityList
        Filter out the unavailable city then append the existing one to filteredCity
        """
        data = cd.city_data
        for i in range(1,len(data)):
            # if city population not empty string,create an object converting population into integer
            if len(data[i][7]) > 0:
                populationInt = int(data[i][7])
                newCity = BakeryCity(data[i][0],data[i][1],data[i][2],data[i][3],data[i][6],populationInt,data[i][8])
                cityList.append(newCity)
            else:   # otherwise create an object where city population remain empty string
                newCity = BakeryCity(data[i][0], data[i][1], data[i][2], data[i][3],data[i][6],data[i][7], data[i][8])
                cityList.append(newCity)

        for city in cityList:  # only cities that are either primary capital or population >= 5 millions will be used
            if city.capital == "primary" or city.population >= 5000000:
                filteredCity.append(city)

    def distance(self):
        """
        Calculate the distance(in kilometre) between 2 cities IDs inputted by users
        """
        departPosition = []     # lat,lng of depart city
        destPosition = []       # lat,lng of destination city
        departCity = ""         # city_ascii of depart city
        destCity = ""           # city_ascii of destination city
        getDeparture = input("Enter the ID of the departure city:\n")
        getDestination = input("Enter the ID of the destination city:\n")
        for city in cityList:
             if city.id == getDeparture:    # get the position of depart city
                 departPosition.append(float(city.lat))
                 departPosition.append(float(city.lng))
                 departCity = city.city_ascii
             if city.id ==  getDestination:     # get the position of destination city
                 destPosition.append(float(city.lat))
                 destPosition.append(float(city.lng))
                 destCity = city.city_ascii
        print(f"Distance between {departCity} and {destCity}:")
        distance = math.ceil(geodesic(destPosition,departPosition).kilometers)   # calculate distance between 2 cities
        print(f"{distance} km")


if __name__ == "__main__":
    cityList = []       # to store all cities created as an object in BakeryCity
    filteredCity = []       # cities that is filtered out via specific conditions from cityList
    print(f"Delivering baked goods to 363 cities.")
    city = BakeryCity("","","","","","","")
    city.newCity()
    city.distance()



