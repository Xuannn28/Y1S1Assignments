from tabulate import tabulate

"""
This program allows users to interact with several options,eg. show rabbytes list,
breed rabbit or wait for 1 year.
"""


class Rabbit():
    """
    Rabbit class represents individual rabbit's behaviour and
    serves several related functions.

    Attributes:
        id       (int):rabbit's id
        sex      (str):rabbit's gender (F/M)
        age      (int):rabbit's age 
        dad      (str):rabbit's dad   
        mom      (str):rabbit's mom
        pregnant (str):rabbit's pregnant status
    """

    def __init__(self, id, sex, age, dad, mom, pregnant):
        self.id = id
        self.sex = sex
        self.age = age
        self.dad = dad
        self.mom = mom
        self.pregnant = pregnant

    def rabbytesList(self):
        """
        Tabulate a table containing rabbit personal detail,
        eg.ID,sex,age,dad,mom and pregnant status.
        @return tabulated rabbits table
        """
        header = ["ID", "Sex", "Age", "Dad", "Mom", "Pregnant"]
        dataList = []     # to store each rabbit detail into a list for table display
        for i, rabbit in enumerate(rabbits):  # to access the index and the rabbits instances in rabbits list
            rabbit.id = i
            data = [rabbit.id, rabbit.sex, rabbit.age, rabbit.dad, rabbit.mom, rabbit.pregnant]
            newTuple = tuple(data)   # each tuple represent each rabbit detail
            dataList.append((newTuple))
        newTable = tabulate(dataList, headers=header, tablefmt="rst")
        return newTable

    def breed(self):
        """
        Breed new rabbit from parents inputted by users 
        and store both parents in a dictionary.
        """
        print("Which rabbytes do you want to breed?")
        rabbitToBreed1 = None
        rabbitToBreed2 = None

        while True:
            parent1 = int(input("First parent:\n"))  # get parent1 ID
            if parent1 >= 0 and parent1 < len(rabbits): 
                rabbitToBreed1 = rabbits[parent1]
                if rabbitToBreed1.age == 0:        # parent cannot be at age 0
                    print("Rabbit too young. Try again.")
                    continue
                elif rabbitToBreed1.pregnant == "Yes":     # parent cannot be pregnant
                    print("Rabbit cannot be pregnant. Try again.")
                    continue
                else:
                    break
            else:
                print("Rabbit not found. Try again.")
                continue

        while True:
            parent2 = int(input("Second parent:\n"))  # get parent2 ID
            if parent2 >= 0 and parent2 < len(rabbits):
                rabbitToBreed2 = rabbits[parent2]
                display = ""  # to tell users all the condition that doesn't fulfill the requirement for breeding
                if rabbitToBreed2.age == 0:    # parent cannot be at age 0
                    display += "Rabbit too young. "
                if rabbitToBreed2.sex == rabbitToBreed1.sex:  # cannot same sex with parent1
                    if rabbitToBreed2.sex == "M":
                        display += "Rabbit cannot be male. "
                    else:
                        display += "Rabbit cannot be female. "
                if rabbitToBreed2.pregnant == "Yes":            # cannot be pregnant
                    display += "Rabbit cannot be pregnant. "
                if rabbitToBreed2.age == 0 or rabbitToBreed2.sex == rabbitToBreed1.sex or rabbitToBreed2.pregnant == "Yes":
                    display += "Try again."
                    print(display)
                else:
                    break
            else:
                print("Rabbit not found. Try again.")
                continue

        # valid pair of rabbytes given and a dictionary store mom id as key,dad id as value
        if rabbitToBreed1.sex == "F":  # parent1= mom
            rabbitToBreed1.pregnant = "Yes"
            dictRabbit[rabbitToBreed1.id] = rabbitToBreed2.id
        else:  # parent1=dad
            rabbitToBreed2.pregnant = "Yes"
            dictRabbit[rabbitToBreed2.id] = rabbitToBreed1.id

    def wait(self):
        """
        after 1 year,all rabbit age increase by 1 and 
        pregnant rabbit will give birth to 0 year old kitten.
        """
        for rabbit in rabbits:  # all rabbits age increase by 1
            rabbit.age += 1
        idNum = len(rabbits)  # new rabbit ID
        for rabbit in rabbits:
            if rabbit.pregnant == "Yes":
                rabbit.pregnant = "No"
                # if dad id smaller than mom id,male kitten will be created,otherwise female kitten
                if rabbit.id > dictRabbit[rabbit.id]:
                    newRabbit = Rabbit(idNum, "M", 0, str(dictRabbit[rabbit.id]), str(rabbit.id), "No")
                else:
                    newRabbit = Rabbit(idNum, "F", 0, str(dictRabbit[rabbit.id]), str(rabbit.id), "No")
                idNum += 1
                rabbits.append(newRabbit)  # update rabbits list


# code inside will execute if the script is in main program
if __name__ == "__main__":
    rab0 = Rabbit(0, "M", 0, "", "", "No")
    rab1 = Rabbit(1, "F", 1, "", "", "No")
    rab2 = Rabbit(2, "M", 2, "", "", "No")
    rab3 = Rabbit(3, "F", 3, "", "", "No")
    rab4 = Rabbit(4, "M", 4, "", "", "No")
    rab5 = Rabbit(5, "F", 5, "", "", "No")
    rab6 = Rabbit(6, "M", 6, "", "", "No")

    rabbits = [rab0, rab1, rab2, rab3, rab4, rab5, rab6]  # a list storing all rabbits instances for easy accessibility
    dictRabbit = {}  # { idMom : idDad }
    while True:
        print("==================================")
        print("Enter your choice:")
        print("1. List Rabbytes.")
        print("2. Breed a Rabbit.")
        print("3. Wait 1 year.")
        print("0. Quit.")
        print("==================================")
        option = input()
        rabbit = Rabbit(0, "", 0, "", "", "")  # dummy Rabbit instance
        if option == "1":
            print(rabbit.rabbytesList())
        elif option == "2":
            rabbit.breed()
        elif option == "3":
            rabbit.wait()
        elif option == "0":
            quit()

