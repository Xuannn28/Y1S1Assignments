'''
This program allows users to guess a secret number from a list continuously until the users make a correct guess
'''

#allow users to make guess until correct
while True:
    #the secret numbers are stored in a list
    secretNum=[3,1,7,9,10]
    #allow users to input their guess
    guess=int(input("Input a guess:\n"))
    #to display output
    if guess in secretNum:
        print("Correct!")
        break
    else:
        print("Incorrect!")



    
        

        
