'''
This program converts a number of seconds into seconds,minutes,hours and days,similar to task 1 but unit conversion is defined by users
'''

#to get unit conversion on Trisolaris from users
print("TIME CONFIGURATION ON TRISOLARIS")
seconds=int(input("Number of seconds in a minute on Trisolaris:\n"))
minutes=int(input("Number of minutes in an hour on Trisolaris:\n"))
hours=int(input("Number of hours in an day on Trisolaris:\n"))
print("TIME IN SECONDS")
time=int(input("Duration in seconds:\n"))

#to convert time in seconds into days,hours,minutes,and seconds
total_days=time//(hours*minutes*seconds)
remain_days=time%(hours*minutes*seconds)
total_hours=remain_days//(minutes*seconds)
remain_hours=remain_days%(minutes*seconds)
total_minutes=remain_hours//seconds
remain_minutes=remain_hours%seconds
total_seconds=remain_minutes

#to display output
print("DATE AND TIME ON TRISOLARIS")
print("The date and time on Trisolaris is",total_days,"days",total_hours,"hours",total_minutes,"minutes",total_seconds,"seconds")
