'''
This program will ask users to guess all secret numbers in a list,if guess wrongly,hints will be given
'''
secretNums=[3,1,7,9,10]
myList=[]

#when wrongly guessed,find the difference between user guess and each value in secretNums
#user guess will compare with the number with smallest difference in secretNums,then give a hint to the users

while len(myList)!=5:
    guess=int(input("Input a guess:\n"))
    
    while guess in myList or guess not in secretNums:
        #empty list created to store the difference between secretNums and user guess

        diffList=[]
        for num in range(len(secretNums)):
            diff=abs(secretNums[num]-guess)
            diffList.append(diff)
            index=diffList.index(min(diffList))
            finalNum=secretNums[index]
        if finalNum>guess:
            print("Incorrect!")
            print("The closest unknown secret is greater than your guess.")
            guess=int(input("Input a guess:\n"))
        else:
            print("Incorrect!")
            print("The closest unknown secret is smaller than your guess.")
            guess=int(input("Input a guess:\n"))

    #when user guess is in secretNums,guess will store in myList
    print("Correct!")
    myList.append(guess)
    secretNums.remove(guess)

#all secret numbers is guessed and quit the loop
print("You have guessed all the secrets!")
    




