'''
This program will have 4 keyboards and ask user to input a string,
if the keyboard contain all of the element inputted by user,then it will perform operations
to allow Robbie the robot to type out the inputted value on the keyboard
Robbie can "wrap" around the keyboards,if the steps wrapping around the keyboard is lesser,
Robbie will take the steps and continue the movement
The output will display the keyboard that give the fewest steps and display the steps Robbie has move.
'''

#4 configuration is stored in a keyboards dictionary
keyboards={
    0 : ["abcdefghijklm","nopqrstuvwxyz"],
    1 : ["789","456","123","0.-"],
    2 : ["bemix","clunk","grypt","vozhd","waqfs"],
    3 :  ["chunk", "fjord", "gymps", "vibex", "waltz"]
}

result = ""
myList=[]  #used to store the steps 
myCount=[]  #used to store the number of steps

def main():
    global char_found
    words = input("Enter a string to type:\n")
    char_found=False
#if all the characters in words are found in the keyboard,the operation will perform
    if characterFound(words,keyboards,0):

        rowIndex=lastValueRow(keyboards,0)
        colIndex=lastValueColumn(keyboards,0)
        finalSteps,finalCount=keyboardOperation2(words,keyboards,0,rowIndex,colIndex)
        myList.append(finalSteps)
        myCount.append((finalCount))

        char_found=True
    #if there's a character in words not found in the keyboard,the operation will not perform 
    else:
        myList.append(0)
        myCount.append(0)

    if characterFound(words,keyboards,1):

        rowIndex=lastValueRow(keyboards,1)
        colIndex=lastValueColumn(keyboards,1)
        finalSteps,finalCount=keyboardOperation2(words,keyboards,1,rowIndex,colIndex)
        myList.append(finalSteps)
        myCount.append(finalCount)

        char_found=True

    else:
        myList.append(0)
        myCount.append(0)

    if characterFound(words,keyboards,2):

        rowIndex=lastValueRow(keyboards,2)
        colIndex=lastValueColumn(keyboards,2)
        finalSteps,finalCount=keyboardOperation2(words,keyboards,2,rowIndex,colIndex)
        myList.append(finalSteps)
        myCount.append(finalCount)

        char_found=True

    else:
        myList.append(0)
        myCount.append(0)
        
    if characterFound(words,keyboards,3):

        rowIndex=lastValueRow(keyboards,3)
        colIndex=lastValueColumn(keyboards,3)
        finalSteps,finalCount=keyboardOperation2(words,keyboards,3,rowIndex,colIndex)
        myList.append(finalSteps)
        myCount.append(finalCount)

        char_found=True

    else:
        myList.append(0)
        myCount.append(0)
#to ensure that when there's no character found in every keyboards,we will print the string is not typed out
    if myCount==[0,0,0,0]:
        display(-1,'',char_found)
    else:
        final_key=minValue()
        final_steps=myList[final_key]
        display(final_key,final_steps,char_found)

#to get the minimum value in myCount list to get the fewest steps 
def minValue():

    minValue=min(myCount)
    if minValue==0:

        nonZeroList=[value for value in myCount if value!=0]
        newMin=min(nonZeroList)
        index=myCount.index(newMin)
    else:
        index=myCount.index(minValue)

    return index

#to identify the number of characters found in words in each keyboards
def characterFound(word,keyboard,key):

    if key in keyboard:
        keyboardUsed=keyboard[key]
        for char in word:
            char_found = False

            for values in keyboardUsed:
                for value in values:
                    if char in value:

                        char_found = True
                        break
            if not char_found:
                return False
        return True
    else:
        return False

#to get the last index of row in each keyboard
def lastValueRow(keyboard2,j):
    if j in keyboard2:
        keyboard2Row=keyboard2[j]

        lastRowIndex=len(keyboard2Row)-1

    return lastRowIndex

#to get the last index of column in each keyboard
def lastValueColumn(keyboard3,k):
    if k in keyboard3:
        keyboard3Col=keyboard3[k]

        lastColIndex=len(keyboard3Col[0])-1

    return lastColIndex

#to perform all the movement Robbie need to type out the words
def keyboardOperation2(word,keyboard1, i,rowIndex1,colIndex1): #wrap up
    a=0 #row
    b=0 #column
    steps=""
    count=0
    if i in keyboard1:
        keyboardUsed=keyboard1[i]
    for char in word:
        for row in range(len(keyboardUsed)):
            for column in range(len(keyboardUsed[row])):

                if keyboardUsed[row][column] == char:
                    rowDiff=abs(a-row)
                    if rowDiff>(rowIndex1/2):  #need to wrap
                        rowDiff1=a-0
                        if rowDiff1<=(rowIndex1/4) and row==rowIndex1:
                            steps+=("u"*rowDiff1)
                            count+=rowDiff1
                            a=0

                        rowDiff2=rowIndex1-a
                        if rowDiff2<=(rowIndex1/4) and row==0:
                            steps+=("d"*rowDiff2)
                            count+=rowDiff2
                            a=rowIndex1

                        if a<row:
                            steps+="uw"
                            count+=1
                            a=rowIndex1
                            diff=a-row
                            if diff != 0:
                                steps+=("u"*diff)
                                count+=diff
                                a=row
                            else:
                                a=row
                        if a>row:
                            steps+="dw"
                            count+=1
                            a=0
                            diff=row-a
                            if diff !=0:
                                steps+=("d"*diff)
                                count+=diff
                                a=row
                            else:
                                a=row
                    if rowDiff<=(rowIndex1/2):  #no need to wrap
                        if a>row:
                            diff=a-row
                            steps+=("u"*diff)
                            count+=diff
                            a=row
                        if a<row:
                            diff=row-a
                            steps+=("d"*diff)
                            count+=diff
                            a=row

                    colDiff=abs(b-column)
                    if colDiff>(colIndex1/2):    #need to wrap
                        colDiff1=b-0
                        colDiff2=colIndex1-column
                        if colDiff1<=(colIndex1/4) and colDiff2<=(colIndex1/4):
                            steps+=("l"*colDiff1)
                            count+=colDiff1
                            b=0

                        colDiff3=colIndex1-b
                        colDiff4=column-0
                        if colDiff3<=(colIndex1/4) and colDiff4<=(colIndex1/4):
                            steps+=("r"*colDiff3)
                            count+=colDiff3
                            b=colIndex1

                        if b<column:
                            steps+="lw"
                            count+=1
                            b=colIndex1
                            diff=b-column
                            if diff!=0:
                                steps+=("l"*diff)
                                count+=diff
                                b=column
                            else:
                                b=column
                        if b>column:
                            steps+="rw"
                            count+=1
                            b=0
                            diff=column-b
                            if diff!=0:
                                steps+=("r"*diff)
                                count+=diff
                                b=column
                            else:
                                b=column
                    if colDiff<=(colIndex1/2):   #no need to wrap
                        if b>column:
                            diff=b-column
                            steps+=("l"*diff)
                            count+=diff
                            b=column
                        if b<column:
                            diff=column-b
                            steps+=("r"*diff)
                            count+=diff
                            b=column
                    if a==row and b==column:
                        steps+="p"
                        count+=1
    return steps,count

#to display the output when char_found is True or False
def display(final_keys,final_steps,char_found):

    if char_found==True:
        print("Configuration index:")
        print(final_keys)
        print("The robot must perform the following operations:")
        print(final_steps)
    else:
        print("The string cannot be typed out.")

main()
