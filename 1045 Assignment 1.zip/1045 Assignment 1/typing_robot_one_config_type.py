'''
This program will have a keyboard and ask user to input a string,then plans the actions
of Robbie the robot to type this string on a keyboard.
The output display the movement of Robbie
'''

#a list is created act as the keyboard 
keyboard=["chunk","fjord","gymps","vibex","waltz"]
#allow users to input a string
words=input("Enter a string to type:\n")
#steps is used to display the end result of Robbie movement at end of the program
steps=""
#result is used to concatenate string to string(steps)
result=""

#used to identify whether the letter's position is equal to keyboard's position
for char in words:
        char_found = False
        
        for row in range(len(keyboard)):
            for column in range(len(keyboard[row])):
                if keyboard[row][column] == char:
                    char_found = True
            if char_found:
                break
        if not char_found:
            break

# used to initialiase the original position of the character is at c           
a=0 #row
b=0 #column

#if the letter on the keyboard is equal to the character in words 
#we will compare the index of the row&column of the keyboard with a and b,which is the index of character
#compare with row first,then column so that Robbie move up/down first then left/right. 
#the movement of Robbie from current keyboard's position to desired keyboard's position will be output via steps
for char in words:
        
        for row in range(len(keyboard)):
            for column in range(len(keyboard[row])):
               
                if keyboard[row][column] == char:
                    
                    if a<row: 
                        diff=row-a
                        result=("d"*diff) 
                        steps+=result
                        a=row
                    if a>row: 
                        diff=a-row
                        result=("u"*diff) 
                        steps+=result
                        a=row    
                    if b<column: 
                            diff=column-b  
                            result=("r"*diff) 
                            steps+=result
                            b=column
                    if b>column: 
                            diff=b-column
                            result=("l"*diff)
                            steps+=result
                            b=column
                        

                    if a==row and b==column:
                        steps+="p"          
#if user input is in the keyboard,the block of code for char_found=True will be executed
if char_found==True:                   
    print("The robot must perform the following operations:")
    print(steps)
#when char_found=False,the operation will not continue after informing the users it's invalid input
else:
    print("The string cannot be typed out.")






            
                
                



        

