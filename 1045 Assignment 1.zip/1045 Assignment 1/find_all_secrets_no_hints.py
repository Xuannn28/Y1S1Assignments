'''
This program will ask users to guess all secret numbers in a list
'''
#myList is an empty list to allow the right guess being insert into the list
#secretNum list and myList arrange in ascending form in order to compare with each other to check if all secret numbers is guessed
secretNum=[3,1,7,9,10]
secretNum.sort()
myList=[]

#if myList is not the same as secretNum,the instruction will continue looping to ask users for guesses
while myList!=secretNum:
    guess=int(input("Input a guess:\n"))
    #to prevent same number being insert into myList
    if guess in myList or guess not in secretNum:
        print("Incorrect!")
    
    else:
        print("Correct!")
        myList.append(guess)
        myList.sort()
        
#when myList is equal to secretNum,this message will be display
print("You have guessed all the secrets!")
    
