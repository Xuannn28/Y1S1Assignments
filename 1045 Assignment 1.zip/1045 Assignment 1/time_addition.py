'''
This program will require current time of day and time to wait from users,the unit conversion is also set by users,then display the date(in days,hours,minutes and seconds format) 
'''
#to get unit conversion on Trisolaris from users
print("TIME CONFIGURATION ON TRISOLARIS")
seconds=int(input("Number of seconds in a minute on Trisolaris:\n"))
minutes=int(input("Number of minutes in an hour on Trisolaris:\n"))
hours=int(input("Number of hours in an day on Trisolaris:\n"))

#to get current time on Trisolaris from users
print("CURRENT TIME OF DAY ON TRISOLARIS")
curHour=int(input("Hour of day on Trisolaris:\n"))
curMinute=int(input("Minute of day on Trisolaris:\n"))
curSecond=int(input("Second of day on Trisolaris:\n"))

#to get wait time from users
print("DURATION TO WAIT")
wait=int(input("Duration in seconds:\n"))

#to convert current time obtained from users into seconds and sum up with the waiting time
totalSecond=(curHour*minutes*seconds)+(curMinute*seconds)+curSecond+wait
#to convert totalSecond into days,hours,minutes,seconds
finalDay=totalSecond//(hours*minutes*seconds)
remainDay=totalSecond%(hours*minutes*seconds)
finalHour=remainDay//(minutes*seconds)
remainHour=remainDay%(minutes*seconds)
finalMinute=remainHour//seconds
remainMinute=remainHour%seconds
finalSecond=remainMinute

#to display output
print("DATE AND TIME ON TRISOLARIS AFTER WAITING")
print("The date and time on Trisolaris after waiting is",finalDay,"days",finalHour,"hours",finalMinute,"minutes",finalSecond,"seconds")
