'''
This program will have 4 keyboards and ask user to input a string,
if the keyboard contain all of the element inputted by user,then it will perform operations
to allow Robbie the robot to type out the inputted value on the keyboard
The output will display the keyboard that give the fewest steps and display the steps Robbie has move.
'''
#a dictionary is created to store the 4 keyboards
keyboards={
    0 : ["abcdefghijklm","nopqrstuvwxyz"],
    1 : ["789","456","123","0.-"],
    2 : ["bemix","clunk","grypt","vozhd","waqfs"],
    3 :  ["chunk", "fjord", "gymps", "vibex", "waltz"]
}

#result is used to concatenate string to string(steps)
result = ""
#myList is created to store the length of steps in order to get the fewest steps from the list
myList=[]

#main() is used to call other functions and procedure
def main():
    #allow users to input a string
    words = input("Enter a string to type:\n")
    char_found=False
    #if all character in words contain in keyboards[0],then Robbie the robot allow to perform the operations
    #if ther's one character not found,then the operation will not perform and 0 will be append to myList 
    #same goes to other keyboards (line 28 to line 54)
    if characterFound(words,keyboards,0):
        key0=keyboardOperation(words,keyboards,0)
        myList.append(len(key0))
        char_found=True
    else:
        myList.append(0)

    if characterFound(words,keyboards,1):
        key1=keyboardOperation(words,keyboards,1)
        myList.append(len(key1))
        char_found=True
    else:
        myList.append(0)

    if characterFound(words,keyboards,2):
        key2=keyboardOperation(words,keyboards,2)
        myList.append(len(key2))
        char_found=True
    else:
        myList.append(0)

    if characterFound(words,keyboards,3):
        key3=keyboardOperation(words,keyboards,3)
        myList.append(len(key3))
        char_found=True
    else:
        myList.append(0)

    if myList==[0,0,0,0]:
        display(-1,'',char_found)
    else:
        final_key=minValue()
        final_step=keyboardOperation(words,keyboards,final_key)
        display(final_key,final_step,char_found)

#minValue() function is used to get the index of the minimum steps store in myList
#if there's is 0 in the list,we will create another list without the zero and compare with the newList(nonZeroList)
def minValue():
    minValue=min(myList)
    if minValue==0: 

        nonZeroList=[value for value in myList if value!=0]
        newMin=min(nonZeroList)
        index=myList.index(newMin)
    else:
        index=myList.index(min(myList))

    return index

#characterFound() function is used to determine whether all characters in the string contain in the keyboard
def characterFound(word,keyboard,key):
    global char_found
    if key in keyboard:
        keyboardUsed=keyboard[key]
        for char in word:
            char_found = False
            for values in keyboardUsed:
                for value in values:
                    if char in value:
                        char_found = True
                        break
            if not char_found:
                return False
        return True
    else:
        return False

#keyboardOperation() function is used to allow Robbie the robot to type out the string on the keyboards
#Robot's movement will store in a string called steps
def keyboardOperation(word,keyboard1, i):
    steps = ""
    if i in keyboard1:
        keyboardUsed = keyboard1[i]
    a = 0
    b = 0

    for char in word:

        for row in range(len(keyboardUsed)):
            for column in range(len(keyboardUsed[row])):

                if keyboardUsed[row][column] == char:

                    if a < row:
                        diff = row - a
                        result = ("d" * diff)
                        steps += result
                        a = row
                    if a > row:
                        diff = a - row
                        result = ("u" * diff)
                        steps += result
                        a = row
                    if b < column:
                        diff = column - b
                        result = ("r" * diff)
                        steps += result
                        b = column
                    if b > column:
                        diff = b - column
                        result = ("l" * diff)
                        steps += result
                        b = column

                    if a == row and b == column:
                        steps += "p"


    return steps

#display() procedure is used to display output 
def display(final_keys,final_steps,char_found):

    if char_found==True:
        print("Configuration index:")
        print(final_keys)
        print("The robot must perform the following operations:")
        print(final_steps)
    else:
        print("The string cannot be typed out.")

main()
