'''
This program converts a number of seconds into seconds,minutes,hours and days
'''

print("TIME IN SECONDS")
#allow user to input a value 
num=int(input("Duration in seconds:\n"))

#representing the time in seconds into how many days,hours,minutes and seconds
total_days=num//86400
#the remain variable is used to get the remaining seconds for further conversion
#(which is the remainder of the division) via modulus
remain_days=num%86400
total_hours=remain_days//3600
remain_hours=remain_days%3600
total_minutes=remain_hours//60
remain_minutes=remain_hours%60
total_seconds=remain_minutes

#display output
print("DATE AND TIME")
print("The date and time is",total_days,"days",total_hours,"hours",total_minutes,"minutes",total_seconds,"seconds")
