'''
This program allow users to create rabbit with unique name and input their age.
if no age inputted,it will be assign with "Unknown".
if the rabbit's name is already exist,it will show a message to inform users and ask for input again
'''
#create two empty lists(name,age) to store the new name and age created by users
name = []
age=[]
rabbitInfo=[] #a list to combine name and age list [[name1,name2],[age1,age2])

#use to call out other functions and procedure and ask for users input
def mainMenu():
    while True:
        print("==================================")
        print("Enter your choice:")
        print("1. Create a Rabbit.")
        print("2. Input Age of a Rabbit.")
        print("3. List Rabbytes.")
        print("0. Quit.")
        print("==================================")
        options=input()
        if options.isnumeric():
            if options=="1":
                createRabbit(name,age)
            elif options=="2":
                rabbitAge(name,age)
            elif options=="3":
                rabbytesList(rabbitInfo,name)
            elif options=="0":
                quit()
            else:
                continue
        continue

#a function for users input and append the rabbit name and unknown age to lists
def createRabbit(name1,age1):
    while True:
        getName=input("Input the new rabbit's name:\n")
        if getName in name1:
            print("That name is already in the database.")
            continue
        else:
            name1.append(getName)
            rabbitInfo.append(name1)
            age1.append("Unknown")
            rabbitInfo.append(age1)
            mainMenu()

#a function for users to input rabbit age 
def rabbitAge(name1,age1):
    while True:
        getName = input("Input the rabbit's name:\n")
        if getName not in name1:
            print("That name is not in the database.")
            continue
        else: #when name is in the list,find the index of the name in the list
            getAge=input("Input "+ getName+"'s age:\n")
            index=name1.index(getName)
            if age1[index]=="Unknown":
                age1[index]=getAge
            mainMenu()

#all rabbit name and age created will display out
def rabbytesList(rabbitInfo1,name1):
    print("Rabbytes:")
    for i in range(len(name1)):
        rabbitName=rabbitInfo1[0][i] #[[name1,name2],[age1,age2]]
        rabbitAge=rabbitInfo1[1][i]
        print(f"{rabbitName} ({rabbitAge})")
    mainMenu()


mainMenu()
