'''
This program allow users to create rabbit with unique name,input their age,and create parental relationship with each other
in option 5,when users input a rabbit name,they will show who is their parents or child
if the rabbit's name is already exist,it will show a message to inform users and ask for input again
'''

#dictRabbit is a dictionary where key is the parent and value is the childs
#rabbitInfo is a list to combine name and age list [[name1,name2],[age1,age2])
name = []
age=[]
dictRabbit={}
rabbitInfo=[]

#use to call other functions and procedure and ask for users input
def mainMenu():
    while True:
        print("==================================")
        print("Enter your choice:")
        print("1. Create a Rabbit.")
        print("2. Input Age of a Rabbit.")
        print("3. List Rabbytes.")
        print("4. Create a Parental Relationship.")
        print("5. List Direct Family of a Rabbit.")
        print("0. Quit.")
        print("==================================")
        options=input()
        if options.isnumeric():
            if options=="1":
                createRabbit()
            elif options=="2":
                rabbitAge()
            elif options=="3":
                rabbytesList()
            elif options=="4":
                parentalRelationship()
            elif options=="5":
                familyList()
            elif options=="0":
                quit()
            else:
                continue
        continue

# a procedure ask for users input and append the rabbit name and unknown age to lists
def createRabbit():
    while True:
        getName=input("Input the new rabbit's name:\n")
        if getName in name:
            print("That name is already in the database.")
            continue
        else:
            name.append(getName)
            rabbitInfo.append(name)
            age.append("Unknown")
            rabbitInfo.append(age)
            mainMenu()

#a procedure for users to input rabbit age
def rabbitAge():
    while True:
        getName = input("Input the rabbit's name:\n")
        if getName not in name:
            print("That name is not in the database.")
            continue
        else: #when name is in the list,find the index of the name in the list
            getAge=input("Input "+ getName+"'s age:\n")
            index=name.index(getName)
            if age[index]=="Unknown":
                age[index]=getAge
            mainMenu()

#all rabbit name and age created will display out
def rabbytesList():
    print("Rabbytes:")
    for i in range(len(name)):
        rabbitName=rabbitInfo[0][i]
        rabbitAge=rabbitInfo[1][i]
        print(f"{rabbitName} ({rabbitAge})")
    mainMenu()

#allow users to create relationship between parents and child 
#if the rabbit name does not exist in name list,it will be created as a new rabbit
#the parent will assign to dictRabbit as key and kitten will assign to dictRabbit as values
def parentalRelationship():
    getParent=input("Input the parent's name:\n")
    if getParent not in name:
        name.append(getParent)
        rabbitInfo.append(name)
        age.append("Unknown")
        rabbitInfo.append(age)
    if getParent not in dictRabbit.keys():
        dictRabbit[getParent]=[]

    getKitten=input("Input the kitten's name:\n")
    if getKitten not in name:
        name.append(getKitten)
        rabbitInfo.append(name)
        age.append("Unknown")
        rabbitInfo.append(age)
    newKitten=dictRabbit[getParent]
    newKitten.append(getKitten)

    mainMenu()

#a procedure to ask users input a rabbit name and the parents or child of the rabbit will be display out
def familyList():
    while True:
        getName=input("Input the rabbit's name:\n")
        if getName not in name:
            print("That name is not in the database.")
            continue
        else:
            break
    print(f"Parents of {getName}:")
    parentList=[]
    for parent,kittens in dictRabbit.items():
        for x in kittens:
            if getName in x:   #if the input is in the list,we will append the parent name into a list
                parentList.append(parent)
    parentList.sort()
    for j in parentList:
        print(j)

    print(f"Kittens of {getName}:")
    if getName in dictRabbit.keys():  #when input is a parent,we will print out the kitten(stored as the values in dictionary)
        kittenName=dictRabbit[getName]
        kittenName.sort()
        for i in kittenName:
            print(i)

mainMenu()
